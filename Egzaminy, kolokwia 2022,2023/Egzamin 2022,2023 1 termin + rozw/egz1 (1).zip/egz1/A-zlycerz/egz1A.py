from egz1Atesty import runtests

def gold(G,V,s,t,r):
  # tu prosze wpisac wlasna implementacje
  pass

# zmien all_tests na True zeby uruchomic wszystkie testy
runtests( gold, all_tests = False )
