from egz1btesty import runtests

def planets( D, C, T, E ):
    # tu prosze wpisac wlasna implementacje
    return -1

# zmien all_tests na True zeby uruchomic wszystkie testy
runtests( planets, all_tests = False )
