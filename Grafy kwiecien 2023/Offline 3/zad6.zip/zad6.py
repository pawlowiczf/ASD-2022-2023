from zad6testy import runtests

def binworker( M ):
    # tu prosze wpisac wlasna implementacje
    return 0

# zmien all_tests na True zeby uruchomic wszystkie testy
runtests( binworker, all_tests = False )
