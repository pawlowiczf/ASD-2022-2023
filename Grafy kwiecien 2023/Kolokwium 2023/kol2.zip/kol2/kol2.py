from kol2testy import runtests

def beautree(G):
    # tu prosze wpisac wlasna implementacje
    return None

# zmien all_tests na True zeby uruchomic wszystkie testy
runtests( beautree, all_tests = False )
