from zad4testy import runtests

def longer( G, s, t ):
    # tu prosze wpisac wlasna implementacje
    return (0,0)

# zmien all_tests na True zeby uruchomic wszystkie testy
runtests( longer, all_tests = False )