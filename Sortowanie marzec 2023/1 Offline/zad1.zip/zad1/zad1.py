from zad1testy import runtests

def ceasar( s ):
    # tu prosze wpisac wlasna implementacje
    return 0

# zmien all_tests na True zeby uruchomic wszystkie testy
runtests( ceasar , all_tests = False )
