from zad3testy import runtests

def strong_string(T):
    # tu prosze wpisac wlasna implementacje
    return -1


# # zmien all_tests na True zeby uruchomic wszystkie testy
runtests( strong_string, all_tests=False )
