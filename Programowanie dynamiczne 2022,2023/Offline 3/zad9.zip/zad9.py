from zad9testy import runtests

def min_cost( O, C, T, L ):
    # tu prosze wpisac wlasna implementacje
    return -1

# zmien all_tests na True zeby uruchomic wszystkie testy
runtests( min_cost, all_tests = False )
