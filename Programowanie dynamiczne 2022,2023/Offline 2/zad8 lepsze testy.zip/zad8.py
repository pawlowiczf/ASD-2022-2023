from zad8testy import runtests


def plan(T):
    # tu prosze wpisac wlasna implementacje
    return None


# zmien all_tests na True zeby uruchomic wszystkie testy
runtests( plan, all_tests = False )

